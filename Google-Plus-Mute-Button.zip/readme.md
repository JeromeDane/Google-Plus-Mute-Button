Google+ Mute Button
=====================

This simple extension injects mute buttons into posts on Google+ (Google Plus) so 
you can easily mute posts with a single click.

If you like this extension, you can always **[buy me a cup of coffee](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=52YLWK9BPCAYN)**.

For updates on this and other projects, follow me on one of the following sites:

[Google+](https://plus.google.com/107905455800180378660/posts) |
[Facebook](https://www.facebook.com/Dane.Jerome) |
[Twitter](https://twitter.com/JeromeDane)

Note: The round "Mute" icon in this extension's icon is by [Black Bear Blanc](http://icondatabase.net/icons/black-bear-blanc/dark-buttons-2/dark-buttons-2-deviceaccessvolumemuted-icon). 

License 
==========

[Creative Commons Attribution 3.0 Unported License](http://creativecommons.org/licenses/by-nc-sa/3.0/)

You can share or modify this work as long as you:

1. Link back to this page
2. Ddon't use this or derivatives of this for commercial use
3. Share your changes so that others can benifit from your improvements. 